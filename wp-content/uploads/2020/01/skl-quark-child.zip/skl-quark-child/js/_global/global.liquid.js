$(document).ready(function () {
  $('.liquid').imgLiquid();
});