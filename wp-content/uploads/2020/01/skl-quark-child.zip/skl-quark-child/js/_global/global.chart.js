const app = require('../utils/app.core');

Chart.defaults.global.defaultFontFamily = "'Exo', sans-serif";
Chart.defaults.global.defaultFontColor = "#363636";
Chart.defaults.global.defaultFontSize = 10;
Chart.defaults.global.defaultFontStyle = 'bold';