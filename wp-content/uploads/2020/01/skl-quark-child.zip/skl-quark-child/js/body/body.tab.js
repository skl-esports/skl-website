const app = require('../utils/app.core');

app.createTab({
  container: '#tab-login-register'
});

app.createTab({
  container: '#tab-product-page'
});