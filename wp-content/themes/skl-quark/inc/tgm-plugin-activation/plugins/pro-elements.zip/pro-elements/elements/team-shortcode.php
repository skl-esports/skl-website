<?php

/**
 * Map Location Shortcode
 */



// [pro_team_element location_columns_pro="" etc...]
add_shortcode( 'pro_team_element', 'pro_team_element_func' );
function pro_team_element_func( $atts, $content = null ) { // New function parameter $content is added!
   extract( shortcode_atts( array(
	   'team_name_pro' => 'John Doe',
	   'team_job_title_pro' => 'Chief Executive',
	   'team_image_pro' => '',
		
		'name_font_size_pro' => '15px',
		'name_font_color_pro' => '#000000',
		'job_title_font_size_pro' => '13px',
		'job_title_font_color_pro' => '#8ea96f',
		
		'description_font_size_pro' => '12px',
		'description_font_color_pro' => '#7b8292',
		'social_media_bg_color' => '#8fa871',
		'social_media_icon_color' => '#ffffff',
		
 	  'pro_btn_icon' => '',
	  'pro_icon_url' => '',
 	  'icon_type' => '',
 	  'icon_fontawesome' => '',
 	  'icon_openiconic' => '',
 	  'icon_typicons' => '',
 	  'icon_entypo' => '',
 	  'icon_linecons' => '',
	  
	  
 	  'pro_btn_icon2' => '',
	  'pro_icon_url2' => '',
 	  'icon_type2' => '',
 	  'icon_fontawesome2' => '',
 	  'icon_openiconic2' => '',
 	  'icon_typicons2' => '',
 	  'icon_entypo2' => '',
 	  'icon_linecons2' => '',
	  
	  
  	  'pro_btn_icon3' => '',
 	  'pro_icon_url3' => '',
  	  'icon_type3' => '',
  	  'icon_fontawesome3' => '',
  	  'icon_openiconic3' => '',
  	  'icon_typicons3' => '',
  	  'icon_entypo3' => '',
  	  'icon_linecons3' => '',
	  
	  
 	  'pro_btn_icon4' => '',
	  'pro_icon_url4' => '',
 	  'icon_type4' => '',
 	  'icon_fontawesome4' => '',
 	  'icon_openiconic4' => '',
 	  'icon_typicons4' => '',
 	  'icon_entypo4' => '',
 	  'icon_linecons4' => '',
	  
	  
 	  'pro_btn_icon5' => '',
	  'pro_icon_url5' => '',
 	  'icon_type5' => '',
 	  'icon_fontawesome5' => '',
 	  'icon_openiconic5' => '',
 	  'icon_typicons5' => '',
 	  'icon_entypo5' => '',
 	  'icon_linecons5' => '',
	  
	  
 	  'pro_btn_icon6' => '',
	  'pro_icon_url6' => '',
 	  'icon_type6' => '',
 	  'icon_fontawesome6' => '',
 	  'icon_openiconic6' => '',
 	  'icon_typicons6' => '',
 	  'icon_entypo6' => '',
 	  'icon_linecons6' => '',
	  
	  
	  
   ), $atts ) );
	
	$content = wpb_js_remove_wpautop($content, true);
   
	$icon_wrapper = false;
	
	if ( 'true' === $pro_btn_icon ) {
		vc_icon_element_fonts_enqueue( $icon_type );

		if ( isset( ${"i_icon_" . $icon_type} ) ) {
			if ( 'pixelicons' === $icon_type ) {
				$icon_wrapper = true;
			}
			$iconClass = ${"i_icon_" . $icon_type};
		} else {
			
			if ( 'openiconic' === $icon_type ) {
				$iconClass = $icon_openiconic;
			}
			elseif ( 'typicons' === $icon_type ) {
				$iconClass = $icon_typicons;
			}
			elseif ( 'entypo' === $icon_type ) {
				$iconClass = $icon_entypo;
			}
			elseif ( 'linecons' === $icon_type ) {
				$iconClass = $icon_linecons;
			}
			 else {
			$iconClass = $icon_fontawesome;}
		}

		if ( $icon_wrapper ) {
			$icon_html = '<i class="vc_btn3-icon"><span class="vc_btn3-icon-inner ' . esc_attr( $iconClass ) . '"></span></i>';
		} else {
			$icon_html = '<i class="vc_btn3-icon ' . esc_attr( $iconClass ) . '"></i>';
		}
		}
		
	
	
		if ( 'true' === $pro_btn_icon2 ) {
			vc_icon_element_fonts_enqueue( $icon_type2 );

			if ( isset( ${"i_icon_" . $icon_type2} ) ) {
				if ( 'pixelicons' === $icon_type2 ) {
					$icon_wrapper = true;
				}
				$iconClass2 = ${"i_icon_" . $icon_type2};
			} else {
			
				if ( 'openiconic' === $icon_type2 ) {
					$iconClass2 = $icon_openiconic2;
				}
				elseif ( 'typicons' === $icon_type2 ) {
					$iconClass2 = $icon_typicons2;
				}
				elseif ( 'entypo' === $icon_type2 ) {
					$iconClass2 = $icon_entypo2;
				}
				elseif ( 'linecons' === $icon_type2 ) {
					$iconClass2 = $icon_linecons2;
				}
				 else {
				$iconClass2 = $icon_fontawesome2;}
			}

			if ( $icon_wrapper ) {
				$icon_html2 = '<i><span class="vc_btn3-icon-inner ' . esc_attr( $iconClass2 ) . '"></span></i>';
			} else {
				$icon_html2 = '<i class="' . esc_attr( $iconClass2 ) . '"></i>';
			}
		}
		
		
		
		
		if ( 'true' === $pro_btn_icon3 ) {
			vc_icon_element_fonts_enqueue( $icon_type3 );

			if ( isset( ${"i_icon_" . $icon_type3} ) ) {
				if ( 'pixelicons' === $icon_type3 ) {
					$icon_wrapper = true;
				}
				$iconClass3 = ${"i_icon_" . $icon_type3};
			} else {
			
				if ( 'openiconic' === $icon_type3 ) {
					$iconClass3 = $icon_openiconic3;
				}
				elseif ( 'typicons' === $icon_type3 ) {
					$iconClass3 = $icon_typicons3;
				}
				elseif ( 'entypo' === $icon_type3 ) {
					$iconClass3 = $icon_entypo3;
				}
				elseif ( 'linecons' === $icon_type3 ) {
					$iconClass3 = $icon_linecons3;
				}
				 else {
				$iconClass3 = $icon_fontawesome3;}
			}

			if ( $icon_wrapper ) {
				$icon_html3 = '<i><span class="vc_btn3-icon-inner ' . esc_attr( $iconClass3 ) . '"></span></i>';
			} else {
				$icon_html3 = '<i class="' . esc_attr( $iconClass3 ) . '"></i>';
			}
		}
		

		
		if ( 'true' === $pro_btn_icon4 ) {
			vc_icon_element_fonts_enqueue( $icon_type4 );

			if ( isset( ${"i_icon_" . $icon_type4} ) ) {
				if ( 'pixelicons' === $icon_type4 ) {
					$icon_wrapper = true;
				}
				$iconClass4 = ${"i_icon_" . $icon_type4};
			} else {
			
				if ( 'openiconic' === $icon_type4 ) {
					$iconClass4 = $icon_openiconic4;
				}
				elseif ( 'typicons' === $icon_type4 ) {
					$iconClass4 = $icon_typicons4;
				}
				elseif ( 'entypo' === $icon_type4 ) {
					$iconClass4 = $icon_entypo4;
				}
				elseif ( 'linecons' === $icon_type4 ) {
					$iconClass4 = $icon_linecons4;
				}
				 else {
				$iconClass4 = $icon_fontawesome4;}
			}

			if ( $icon_wrapper ) {
				$icon_html4 = '<i><span class="vc_btn3-icon-inner ' . esc_attr( $iconClass4 ) . '"></span></i>';
			} else {
				$icon_html4 = '<i class="' . esc_attr( $iconClass4 ) . '"></i>';
			}
		}
		
		
		if ( 'true' === $pro_btn_icon5 ) {
			vc_icon_element_fonts_enqueue( $icon_type5 );

			if ( isset( ${"i_icon_" . $icon_type5} ) ) {
				if ( 'pixelicons' === $icon_type5 ) {
					$icon_wrapper = true;
				}
				$iconClass5 = ${"i_icon_" . $icon_type5};
			} else {
			
				if ( 'openiconic' === $icon_type5 ) {
					$iconClass5 = $icon_openiconic5;
				}
				elseif ( 'typicons' === $icon_type5 ) {
					$iconClass5 = $icon_typicons5;
				}
				elseif ( 'entypo' === $icon_type5 ) {
					$iconClass5 = $icon_entypo5;
				}
				elseif ( 'linecons' === $icon_type5 ) {
					$iconClass5 = $icon_linecons5;
				}
				 else {
				$iconClass5 = $icon_fontawesome5;}
			}

			if ( $icon_wrapper ) {
				$icon_html5 = '<i><span class="vc_btn3-icon-inner ' . esc_attr( $iconClass5 ) . '"></span></i>';
			} else {
				$icon_html5 = '<i class="' . esc_attr( $iconClass5 ) . '"></i>';
			}
		}
		
		
		
		if ( 'true' === $pro_btn_icon6 ) {
			vc_icon_element_fonts_enqueue( $icon_type6 );

			if ( isset( ${"i_icon_" . $icon_type6} ) ) {
				if ( 'pixelicons' === $icon_type6 ) {
					$icon_wrapper = true;
				}
				$iconClass6 = ${"i_icon_" . $icon_type6};
			} else {
			
				if ( 'openiconic' === $icon_type6 ) {
					$iconClass6 = $icon_openiconic6;
				}
				elseif ( 'typicons' === $icon_type6 ) {
					$iconClass6 = $icon_typicons6;
				}
				elseif ( 'entypo' === $icon_type6 ) {
					$iconClass6 = $icon_entypo6;
				}
				elseif ( 'linecons' === $icon_type6 ) {
					$iconClass6 = $icon_linecons6;
				}
				 else {
				$iconClass6 = $icon_fontawesome6;}
			}

			if ( $icon_wrapper ) {
				$icon_html6 = '<i><span class="vc_btn3-icon-inner ' . esc_attr( $iconClass6 ) . '"></span></i>';
			} else {
				$icon_html6 = '<i class="' . esc_attr( $iconClass6 ) . '"></i>';
			}
		}
		
	
	
	$output_pro = '';
	
	STATIC $idpro = 0;
	$idpro++;
	
	ob_start();
	?>
			
	
		<div class="team-member-profile" style ="font-size:<?php echo esc_attr( $description_font_size_pro ) ?>; color:<?php echo esc_attr( $description_font_color_pro ) ?>;">
			<?php if($team_image_pro): ?>
				<?php $image = wp_get_attachment_image_src($team_image_pro, 'large'); ?>
				<div class="team-image-pro"><img src="<?php echo esc_attr($image[0]);?>" alt="<?php echo esc_attr( $team_name_pro ) ?>"></div>
			<?php endif; ?>
			
				<?php if($team_name_pro): ?><h5 style ="font-size:<?php echo esc_attr( $name_font_size_pro ) ?>; color:<?php echo esc_attr( $name_font_color_pro ) ?>;"><?php echo esc_attr( $team_name_pro ) ?></h5><?php endif; ?>
				<?php if($team_job_title_pro): ?><h6 style ="font-size:<?php echo esc_attr( $job_title_font_size_pro ) ?>; color:<?php echo esc_attr( $job_title_font_color_pro ) ?>;"><?php echo esc_attr( $team_job_title_pro ) ?></h6><?php endif; ?>				
				<?php if($content): ?><div class="team-description-pro"><?php echo wp_kses_post( $content ) ?></div><?php endif; ?>
			
				<div class="team-social-container-pro">
					<?php if($pro_btn_icon): ?>
						<a href="<?php echo esc_attr($pro_icon_url);?>" style="<?php if($social_media_bg_color): ?>background:<?php echo esc_attr( $social_media_bg_color ) ?>;<?php endif; ?><?php if($team_image_pro): ?> color:<?php echo esc_attr( $social_media_icon_color ) ?>;<?php endif; ?>" target="_blank"><?php echo  wp_kses_post($icon_html); ?></a>
					<?php endif; ?>
				
					<?php if($pro_btn_icon2): ?>
						<a href="<?php echo esc_attr($pro_icon_url2);?>" target="_blank" style="<?php if($social_media_bg_color): ?>background:<?php echo esc_attr( $social_media_bg_color ) ?>;<?php endif; ?><?php if($team_image_pro): ?> color:<?php echo esc_attr( $social_media_icon_color ) ?>;<?php endif; ?>"><?php echo  wp_kses_post($icon_html2); ?></a>
					<?php endif; ?>
				
					<?php if($pro_btn_icon3): ?>
						<a href="<?php echo esc_attr($pro_icon_url3);?>" target="_blank" style="<?php if($social_media_bg_color): ?>background:<?php echo esc_attr( $social_media_bg_color ) ?>;<?php endif; ?><?php if($team_image_pro): ?> color:<?php echo esc_attr( $social_media_icon_color ) ?>;<?php endif; ?>"><?php echo  wp_kses_post($icon_html3); ?></a>
					<?php endif; ?>
				
					<?php if($pro_btn_icon4): ?>
						<a href="<?php echo esc_attr($pro_icon_url4);?>" target="_blank" style="<?php if($social_media_bg_color): ?>background:<?php echo esc_attr( $social_media_bg_color ) ?>;<?php endif; ?><?php if($team_image_pro): ?> color:<?php echo esc_attr( $social_media_icon_color ) ?>;<?php endif; ?>"><?php echo  wp_kses_post($icon_html4); ?></a>
					<?php endif; ?>
				
					<?php if($pro_btn_icon5): ?>
						<a href="<?php echo esc_attr($pro_icon_url5);?>" target="_blank" style="<?php if($social_media_bg_color): ?>background:<?php echo esc_attr( $social_media_bg_color ) ?>;<?php endif; ?><?php if($team_image_pro): ?> color:<?php echo esc_attr( $social_media_icon_color ) ?>;<?php endif; ?>"><?php echo  wp_kses_post($icon_html5); ?></a>
					<?php endif; ?>
				
					<?php if($pro_btn_icon6): ?>
						<a href="<?php echo esc_attr($pro_icon_url6);?>" target="_blank" style="<?php if($social_media_bg_color): ?>background:<?php echo esc_attr( $social_media_bg_color ) ?>;<?php endif; ?><?php if($team_image_pro): ?> color:<?php echo esc_attr( $social_media_icon_color ) ?>;<?php endif; ?>"><?php echo  wp_kses_post($icon_html6); ?></a>
					<?php endif; ?>
				
					<div class="clearfix-pro"></div>
				</div><!-- close .team-social-container-pro -->
		</div><!-- close .team-member-profile -->
	

    <?php
	
   	return $output_pro. ob_get_clean();
	
}


add_action( 'vc_before_init', 'pro_team_element_integrateVC' );
function pro_team_element_integrateVC() {
   vc_map( array(
      "name" => __( "Pro Team", "pro-elements" ),
	  "description" => __( "Add Team Members", "pro-elements" ),
      "base" => "pro_team_element",
	  "weight" => 100,
      "class" => "",
      "category" => __( "Pro Elements", "pro-elements"),
	  'icon' => 'vc-icon',

      "params" => array(
         array(
           "type" => "attach_image",
			"class" => "",
            "heading" => __( "Photograph", "pro-elements" ),
            "param_name" => "team_image_pro",
            "value" => __( "", "pro-elements" ),
         ),
          array(
            "type" => "textfield",
			"holder" => "div",
 			"class" => "",
             "heading" => __( "Name", "pro-elements" ),
             "param_name" => "team_name_pro",
             "value" => __( "John Doe", "pro-elements" ),
          ),
          array(
            "type" => "textfield",
			"holder" => "div",
 			"class" => "",
             "heading" => __( "Job Title", "pro-elements" ),
             "param_name" => "team_job_title_pro",
             "value" => __( "Chief Executive", "pro-elements" ),
          ),
			 
          array(
            "type" => "textarea_html",
 			"class" => "",
             "heading" => __( "Description", "pro-elements" ),
             "param_name" => "content",
             "value" => __( "", "pro-elements" ),
          ),

			 
          array(
             "type" => "checkbox",
             "class" => "",
             "heading" => __( "Add Icon?", "pro-elements" ),
             "param_name" => "pro_btn_icon",
          ),
			 
          array(
            "type" => "textfield",
 			"class" => "",
             "heading" => __( "Icon Link", "pro-elements" ),
             "param_name" => "pro_icon_url",
             "value" => __( "", "pro-elements" ),
	   			'dependency' => array(
	   				'element' => 'pro_btn_icon',
	   				'not_empty' => true,
	   			),
          ),
			 
  			 array(
  			'type' => 'dropdown',
  			'heading' => __( 'Icon library', 'progression' ),
  			'value' => array(
  				__( 'Font Awesome', 'progression' ) => 'fontawesome',
  				__( 'Open Iconic', 'progression' ) => 'openiconic',
  				__( 'Typicons', 'progression' ) => 'typicons',
  				__( 'Entypo', 'progression' ) => 'entypo',
  				__( 'Linecons', 'progression' ) => 'linecons',
  			),
  			'dependency' => array(
  				'element' => 'pro_btn_icon',
  				'not_empty' => true,
  			),
  			'param_name' => 'icon_type',
  			'description' => __( 'Select icon library.', 'progression' ),
  		),
  		array(
  			'type' => 'iconpicker',
  			'heading' => __( 'Icon', 'progression' ),
  			'param_name' => 'icon_fontawesome',
  			'value' => 'fa fa-info-circle',
  			'settings' => array(
  				'emptyIcon' => false, // default true, display an "EMPTY" icon?
  				'iconsPerPage' => 200, // default 100, how many icons per/page to display
  			),
  			'dependency' => array(
  				'element' => 'icon_type',
  				'value' => 'fontawesome',
  			),
  			'description' => __( 'Select icon from library.', 'progression' ),
  		),
  		array(
  			'type' => 'iconpicker',
  			'heading' => __( 'Icon', 'progression' ),
  			'param_name' => 'icon_openiconic',
  			'settings' => array(
  				'emptyIcon' => false, // default true, display an "EMPTY" icon?
  				'type' => 'openiconic',
  				'iconsPerPage' => 200, // default 100, how many icons per/page to display
  			),
  			'dependency' => array(
  				'element' => 'icon_type',
  				'value' => 'openiconic',
  			),
  			'description' => __( 'Select icon from library.', 'progression' ),
  		),
  		array(
  			'type' => 'iconpicker',
  			'heading' => __( 'Icon', 'progression' ),
  			'param_name' => 'icon_typicons',
  			'settings' => array(
  				'emptyIcon' => false, // default true, display an "EMPTY" icon?
  				'type' => 'typicons',
  				'iconsPerPage' => 200, // default 100, how many icons per/page to display
  			),
  			'dependency' => array(
  				'element' => 'icon_type',
  				'value' => 'typicons',
  			),
  			'description' => __( 'Select icon from library.', 'progression' ),
  		),
  		array(
  			'type' => 'iconpicker',
  			'heading' => __( 'Icon', 'progression' ),
  			'param_name' => 'icon_entypo',
  			'settings' => array(
  				'emptyIcon' => false, // default true, display an "EMPTY" icon?
  				'type' => 'entypo',
  				'iconsPerPage' => 300, // default 100, how many icons per/page to display
  			),
  			'dependency' => array(
  				'element' => 'icon_type',
  				'value' => 'entypo',
  			),
  		),
  		array(
  			'type' => 'iconpicker',
  			'heading' => __( 'Icon', 'progression' ),
  			'param_name' => 'icon_linecons',
  			'settings' => array(
  				'emptyIcon' => false, // default true, display an "EMPTY" icon?
  				'type' => 'linecons',
  				'iconsPerPage' => 200, // default 100, how many icons per/page to display
  			),
  			'dependency' => array(
  				'element' => 'icon_type',
  				'value' => 'linecons',
  			),
  			'description' => __( 'Select icon from library.', 'progression' ),
  		),
		
		
		
      array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __( "Add Second Icon?", "pro-elements" ),
         "param_name" => "pro_btn_icon2",
      ),
		
		
     	array(
        "type" => "textfield",
		  "class" => "",
         "heading" => __( "Icon Link", "pro-elements" ),
         "param_name" => "pro_icon_url2",
         "value" => __( "", "pro-elements" ),
  			'dependency' => array(
  				'element' => 'pro_btn_icon2',
  				'not_empty' => true,
  			),
      ),
	 
	 array(
	'type' => 'dropdown',
	'heading' => __( 'Icon library', 'progression' ),
	'value' => array(
		__( 'Font Awesome', 'progression' ) => 'fontawesome',
		__( 'Open Iconic', 'progression' ) => 'openiconic',
		__( 'Typicons', 'progression' ) => 'typicons',
		__( 'Entypo', 'progression' ) => 'entypo',
		__( 'Linecons', 'progression' ) => 'linecons',
	),
	'dependency' => array(
		'element' => 'pro_btn_icon2',
		'not_empty' => true,
	),
	'param_name' => 'icon_type2',
	'description' => __( 'Select icon library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_fontawesome2',
	'value' => 'fa fa-info-circle',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type2',
		'value' => 'fontawesome',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_openiconic2',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'openiconic',
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type2',
		'value' => 'openiconic',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_typicons2',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'typicons',
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type2',
		'value' => 'typicons',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_entypo2',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'entypo',
		'iconsPerPage' => 300, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type2',
		'value' => 'entypo',
	),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_linecons2',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'linecons',
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type2',
		'value' => 'linecons',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),

		
		
      array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __( "Add Third Icon?", "pro-elements" ),
         "param_name" => "pro_btn_icon3",
      ),
		
		
		
     	array(
        "type" => "textfield",
		  "class" => "",
         "heading" => __( "Icon Link", "pro-elements" ),
         "param_name" => "pro_icon_url3",
         "value" => __( "", "pro-elements" ),
  			'dependency' => array(
  				'element' => 'pro_btn_icon3',
  				'not_empty' => true,
  			),
      ),
	 
	 array(
	'type' => 'dropdown',
	'heading' => __( 'Icon library', 'progression' ),
	'value' => array(
		__( 'Font Awesome', 'progression' ) => 'fontawesome',
		__( 'Open Iconic', 'progression' ) => 'openiconic',
		__( 'Typicons', 'progression' ) => 'typicons',
		__( 'Entypo', 'progression' ) => 'entypo',
		__( 'Linecons', 'progression' ) => 'linecons',
	),
	'dependency' => array(
		'element' => 'pro_btn_icon3',
		'not_empty' => true,
	),
	'param_name' => 'icon_type3',
	'description' => __( 'Select icon library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_fontawesome3',
	'value' => 'fa fa-info-circle',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type3',
		'value' => 'fontawesome',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_openiconic3',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'openiconic',
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type3',
		'value' => 'openiconic',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_typicons3',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'typicons',
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type3',
		'value' => 'typicons',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_entypo3',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'entypo',
		'iconsPerPage' => 300, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type3',
		'value' => 'entypo',
	),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_linecons3',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'linecons',
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type3',
		'value' => 'linecons',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
		
		
		
		
		
      array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __( "Add Fourth Icon?", "pro-elements" ),
         "param_name" => "pro_btn_icon4",
      ),
		
		
		
     	array(
        "type" => "textfield",
		  "class" => "",
         "heading" => __( "Icon Link", "pro-elements" ),
         "param_name" => "pro_icon_url4",
         "value" => __( "", "pro-elements" ),
  			'dependency' => array(
  				'element' => 'pro_btn_icon4',
  				'not_empty' => true,
  			),
      ),
	 
	 array(
	'type' => 'dropdown',
	'heading' => __( 'Icon library', 'progression' ),
	'value' => array(
		__( 'Font Awesome', 'progression' ) => 'fontawesome',
		__( 'Open Iconic', 'progression' ) => 'openiconic',
		__( 'Typicons', 'progression' ) => 'typicons',
		__( 'Entypo', 'progression' ) => 'entypo',
		__( 'Linecons', 'progression' ) => 'linecons',
	),
	'dependency' => array(
		'element' => 'pro_btn_icon4',
		'not_empty' => true,
	),
	'param_name' => 'icon_type4',
	'description' => __( 'Select icon library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_fontawesome4',
	'value' => 'fa fa-info-circle',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type4',
		'value' => 'fontawesome',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_openiconic4',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'openiconic',
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type4',
		'value' => 'openiconic',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_typicons4',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'typicons',
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type4',
		'value' => 'typicons',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_entypo4',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'entypo',
		'iconsPerPage' => 300, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type4',
		'value' => 'entypo',
	),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_linecons4',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'linecons',
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type4',
		'value' => 'linecons',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
		
		
      array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __( "Add Fifth Icon?", "pro-elements" ),
         "param_name" => "pro_btn_icon5",
      ),
		
		
		
		
     	array(
        "type" => "textfield",
		  "class" => "",
         "heading" => __( "Icon Link", "pro-elements" ),
         "param_name" => "pro_icon_url5",
         "value" => __( "", "pro-elements" ),
  			'dependency' => array(
  				'element' => 'pro_btn_icon5',
  				'not_empty' => true,
  			),
      ),
	 
	 array(
	'type' => 'dropdown',
	'heading' => __( 'Icon library', 'progression' ),
	'value' => array(
		__( 'Font Awesome', 'progression' ) => 'fontawesome',
		__( 'Open Iconic', 'progression' ) => 'openiconic',
		__( 'Typicons', 'progression' ) => 'typicons',
		__( 'Entypo', 'progression' ) => 'entypo',
		__( 'Linecons', 'progression' ) => 'linecons',
	),
	'dependency' => array(
		'element' => 'pro_btn_icon5',
		'not_empty' => true,
	),
	'param_name' => 'icon_type5',
	'description' => __( 'Select icon library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_fontawesome5',
	'value' => 'fa fa-info-circle',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type5',
		'value' => 'fontawesome',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_openiconic5',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'openiconic',
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type5',
		'value' => 'openiconic',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_typicons5',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'typicons',
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type5',
		'value' => 'typicons',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_entypo5',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'entypo',
		'iconsPerPage' => 300, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type5',
		'value' => 'entypo',
	),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_linecons5',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'linecons',
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type5',
		'value' => 'linecons',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
		
		
      array(
         "type" => "checkbox",
         "class" => "",
         "heading" => __( "Add Sixth Icon?", "pro-elements" ),
         "param_name" => "pro_btn_icon6",
      ),
		
		
		
     	array(
        "type" => "textfield",
		  "class" => "",
         "heading" => __( "Icon Link", "pro-elements" ),
         "param_name" => "pro_icon_url6",
         "value" => __( "", "pro-elements" ),
  			'dependency' => array(
  				'element' => 'pro_btn_icon6',
  				'not_empty' => true,
  			),
      ),
	 
	 array(
	'type' => 'dropdown',
	'heading' => __( 'Icon library', 'progression' ),
	'value' => array(
		__( 'Font Awesome', 'progression' ) => 'fontawesome',
		__( 'Open Iconic', 'progression' ) => 'openiconic',
		__( 'Typicons', 'progression' ) => 'typicons',
		__( 'Entypo', 'progression' ) => 'entypo',
		__( 'Linecons', 'progression' ) => 'linecons',
	),
	'dependency' => array(
		'element' => 'pro_btn_icon6',
		'not_empty' => true,
	),
	'param_name' => 'icon_type6',
	'description' => __( 'Select icon library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_fontawesome6',
	'value' => 'fa fa-info-circle',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type6',
		'value' => 'fontawesome',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_openiconic6',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'openiconic',
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type6',
		'value' => 'openiconic',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_typicons6',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'typicons',
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type6',
		'value' => 'typicons',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_entypo6',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'entypo',
		'iconsPerPage' => 300, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type6',
		'value' => 'entypo',
	),
),
array(
	'type' => 'iconpicker',
	'heading' => __( 'Icon', 'progression' ),
	'param_name' => 'icon_linecons6',
	'settings' => array(
		'emptyIcon' => false, // default true, display an "EMPTY" icon?
		'type' => 'linecons',
		'iconsPerPage' => 200, // default 100, how many icons per/page to display
	),
	'dependency' => array(
		'element' => 'icon_type6',
		'value' => 'linecons',
	),
	'description' => __( 'Select icon from library.', 'progression' ),
),

	
	
	
	
	

array(
   "type" => "textfield",
   "class" => "",
   "heading" => __( "Name Font Size", "pro-elements" ),
   "param_name" => "name_font_size_pro",
	'group' => __( 'Design options', 'pro-elements' ),
	"std"         => '15px',
),

array(
   "type" => "colorpicker",
	"class" => "",
   "heading" => __( "Name Font Color", "pro-elements" ),
   "param_name" => "name_font_color_pro",
	"std"         => '#000000',
	'group' => __( 'Design options', 'pro-elements' ),
),




array(
   "type" => "textfield",
   "class" => "",
   "heading" => __( "Job Title Font Size", "pro-elements" ),
   "param_name" => "job_title_font_size_pro",
	'group' => __( 'Design options', 'pro-elements' ),
	"std"         => '13px',
),

array(
   "type" => "colorpicker",
	"class" => "",
   "heading" => __( "Job Title Font Color", "pro-elements" ),
   "param_name" => "job_title_font_color_pro",
	"std"         => '#8ea96f',
	'group' => __( 'Design options', 'pro-elements' ),
),

array(
   "type" => "textfield",
   "class" => "",
   "heading" => __( "Description Font Size", "pro-elements" ),
   "param_name" => "description_font_size_pro",
	'group' => __( 'Design options', 'pro-elements' ),
	"std"         => '12px',
),

array(
   "type" => "colorpicker",
	"class" => "",
   "heading" => __( "Description Font Color", "pro-elements" ),
   "param_name" => "description_font_color_pro",
	"std"         => '#7b8292',
	'group' => __( 'Design options', 'pro-elements' ),
),




array(
   "type" => "colorpicker",
	"class" => "",
   "heading" => __( "Social Media Background Color", "pro-elements" ),
   "param_name" => "social_media_bg_color",
	"std"         => '#8fa871',
	'group' => __( 'Design options', 'pro-elements' ),
),
		


array(
   "type" => "colorpicker",
	"class" => "",
   "heading" => __( "Social Media Icon Color", "pro-elements" ),
   "param_name" => "social_media_icon_color",
	"std"         => '#ffffff',
	'group' => __( 'Design options', 'pro-elements' ),
),	



      )
   ) );
}