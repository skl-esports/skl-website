<?php

/**
 * Blog Shortcode
 */


// [pro_blog heading_pro="" menu_description_pro="" etc...]
add_shortcode( 'pro_blog', 'pro_blog_func' );
function pro_blog_func( $atts, $content = null ) { // New function parameter $content is added!
   extract( shortcode_atts( array(
	  'post_columns' => '3',
	  'blog_post_count' => '9',
	  'shop_filter_categories' => '',
	  'port_heading_size_pro' => '',
	  'shop_pagination_on_off' => 'true',
	  'blog_heading_size_pro' => '',
	  'meta_size_pro' => '',
	  'blog_paragraph_size_pro' => '',
	  
   ), $atts ) );
   
    $output_pro = '';
	
	STATIC $idpro = 0;
	$idpro++;
	
	ob_start();
	?>
	
	
	
	<?php
	if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } else if ( get_query_var('page') ) {   $paged = get_query_var('page'); } else {  $paged = 1; }
	global $blogloop;
	global $post;
	
	$postIds = $shop_filter_categories; // get custom field value
    $arrayIds = explode(',', $postIds); // explode value into an array of ids
    if(count($arrayIds) <= 1) // if array contains one element or less, there's spaces after comma's, or you only entered one id
    {
        if( strpos($arrayIds[0], ',') !== false )// if the first array value has commas, there were spaces after ids entered
        {
            $arrayIds = array(); // reset array
            $arrayIds = explode(', ', $postIds); // explode ids with space after comma's
        }
    }
	
	if ( $shop_filter_categories ) {
	   	$blogloop = new WP_Query(
	   		array(
	   	   'post_type' => 'post',
	   	   'posts_per_page' => $blog_post_count,
				'paged' => $paged,
				'tax_query' => array(
				        // Note: tax_query expects an array of arrays!
				        array(
				            'taxonomy' => 'category', // 
				            'field'    => 'slug',
				            'terms'    => $arrayIds
				        )
				 ),
	   		)
	    );
	}
	
	else
	  {
   	$blogloop = new WP_Query(
   		array(
   	        'post_type' => 'post',
   	        'posts_per_page' => $blog_post_count,
				  'paged' => $paged
   		)
    );
	}
	
	?>
	
	<div class="blog-pro-vc">
				<?php 
				$count = 1;
				$count_2 = 1;
				$col_count_progression = $post_columns;
				while($blogloop->have_posts()): $blogloop->the_post();
					if($count >= 1+$col_count_progression) { $count = 1; }
						?>						
						<div class="grid<?php echo esc_attr($post_columns) ?>column-progression <?php if($count == $post_columns): echo ' lastcolumn-progression'; endif; ?>">
							<?php include(locate_template('template-parts/visual-composer/content.php')); ?>
						</div><!-- close event columns -->
						<?php if($count == $post_columns): ?><div class="clearfix-pro"></div><?php endif; ?>
				<?php  $count ++; $count_2++; endwhile; // end of the loop. ?>
	<div class="clearfix-pro"></div>
	</div><!-- close .shop-pro-vc -->
	
	
	<?php if($shop_pagination_on_off == 'true'): ?>
		<?php show_pagination_links_blog( ); ?>
		<div class="clearfix-pro"></div>
	<?php endif; ?>
	

	
	<?php wp_reset_query(); ?>
	
	<div class="clearfix-pro"></div>

	<?php
	
	return $output_pro. ob_get_clean();
	
}


add_action( 'vc_before_init', 'pro_blog_integrateVC' );
function pro_blog_integrateVC() {
   vc_map( array(
      "name" => __( "Pro Blog", "pro-elements" ),
	  "description" => __( "List of posts", "pro-elements" ),
      "base" => "pro_blog",
	  "weight" => 100,
      "class" => "",
      "category" => __( "Pro Elements", "pro-elements"),
	  'icon' => 'vc-icon',

      "params" => array(

		 
         array(
            "type" => "dropdown",
			"class" => "",
            "heading" => __( "Post Columns", "pro-elements" ),
            "param_name" => "post_columns",
			"value"       => array(
			        '1 Column'   	=> '1',
			        '2 Columns'  	=> '2',
			        '3 Columns'		=> '3',
			        '4 Columns'  	=> '4',
					  '5 Columns'  	=> '5',
					  '6 Columns'  	=> '6',
			),
			"std"         => '3',
         ),
		 
		 
         array(
            "type" => "textfield",
			"class" => "",
            "heading" => __( "Post Count", "pro-elements" ),
            "param_name" => "blog_post_count",
			"std"         => '9',
         ),
         
		 
         array(
            "type" => "textfield",
			"class" => "",
            "heading" => __( "Narrow by Category", "pro-elements" ),
			"description" => __( "Enter Category slugs to display a specific category. Add-in multiple slugs seperated by a comma to use multiple categories. (Leave blank to pull in all posts).", "pro-elements" ),
            "param_name" => "shop_filter_categories",
			"std"         => '',
         ),
			


         array(
            "type" => "checkbox",
			"class" => "",
            "heading" => __( "Display Pagination?", "pro-elements" ),
            "param_name" => "shop_pagination_on_off",
			"std"         => 'true',
         ),
			
			
			
         array(
            "type" => "textfield",
				"class" => "",
            "heading" => __( "Heading Font Size", "qube-elements" ),
				"description" => __( "Over-rides the default Heading Font Size. Example: 18px", "qube-elements" ),
            "param_name" => "blog_heading_size_pro",
			"std"         => '',
			'group' => __( 'Design options', 'pro-elements' ),
         ),
			
         array(
            "type" => "textfield",
			"class" => "",
            "heading" => __( "Meta Font Size", "qube-elements" ),
				"description" => __( "Over-rides the default Meta Font Size. Example: 12px", "qube-elements" ),
            "param_name" => "meta_size_pro",
			"std"         => '',
			'group' => __( 'Design options', 'pro-elements' ),
         ),
			
         array(
            "type" => "textfield",
				"class" => "",
            "heading" => __( "Paragraph Font Size", "qube-elements" ),
				"description" => __( "Over-rides the default Paragraph Font Size. Example: 11px", "qube-elements" ),
            "param_name" => "blog_paragraph_size_pro",
			"std"         => '',
			'group' => __( 'Design options', 'pro-elements' ),
         ),
			
         
			
      )
   ) );
}